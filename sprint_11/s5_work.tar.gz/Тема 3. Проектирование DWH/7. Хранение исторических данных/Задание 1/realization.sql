UPDATE clients 
SET login = 'arthur_dent' 
WHERE client_id = 42;