create SCHEMA IF NOT EXISTS stg;

CREATE TABLE stg.bonussystem_users (
	id integer NOT NULL,
	order_user_id text NOT NULL
);


CREATE TABLE stg.bonussystem_ranks (
	id integer NOT NULL,
	"name" varchar(2048) NOT NULL,
	bonus_percent numeric(19, 5) DEFAULT 0 NOT NULL,
	min_payment_threshold numeric(19, 5) DEFAULT 0 NOT NULL
);


CREATE TABLE stg.bonussystem_events (
	id integer NOT NULL,
	event_ts timestamp NOT NULL,
	event_type varchar NOT NULL,
	event_value text NOT NULL
);
CREATE INDEX idx_bonussystem_events__event_ts ON stg.bonussystem_events USING btree (event_ts);
