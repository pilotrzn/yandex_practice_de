CREATE TABLE stg.ordersystem_users(
    id serial PRIMARY key,
    object_id varchar not null,
    object_value text not null,
    update_ts timestamp not null
);

CREATE TABLE stg.ordersystem_restaurants(
    id serial PRIMARY key,
    object_id varchar not null,
    object_value text not null,
    update_ts timestamp not null
);

CREATE TABLE stg.ordersystem_orders(
    id serial PRIMARY key,
    object_id varchar not null,
    object_value text not null,
    update_ts timestamp not null
);