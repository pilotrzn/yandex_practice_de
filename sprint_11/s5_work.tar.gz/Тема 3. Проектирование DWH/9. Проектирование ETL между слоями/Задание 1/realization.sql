INSERT INTO cdm.dm_settlement_report
(restaurant_id, 
restaurant_name, 
settlement_date, 
orders_count, 
orders_total_sum, 
orders_bonus_payment_sum, 
orders_bonus_granted_sum, 
order_processing_fee, 
restaurant_reward_sum)
SELECT 
dr.restaurant_id, 
dr.restaurant_name,
dt."date",
count(DISTINCT fps.order_id) count ,
sum(fps.total_sum) total_sum ,
sum(fps.bonus_payment) bonus_payment ,
sum(fps.bonus_grant) bonus_grant,
0.25 * sum(fps.total_sum) order_processing_fee,
sum(fps.total_sum) - sum(fps.bonus_payment) - 0.25 * sum(fps.total_sum) restaurant_reward_sum
FROM dds.dm_orders ord
INNER JOIN dds.dm_timestamps dt ON ord.timestamp_id = dt.id 
INNER JOIN dds.dm_restaurants dr ON ord.restaurant_id = dr.id 
LEFT JOIN dds.fct_product_sales fps ON fps.order_id = ord.id 
WHERE order_status = 'CLOSED'
GROUP BY dr.restaurant_id, 
dr.restaurant_name,
dt."date" 
ON CONFLICT (restaurant_id, settlement_date) 
DO UPDATE SET
    restaurant_name = EXCLUDED.restaurant_name,
    orders_count = EXCLUDED.orders_count,
    orders_total_sum = EXCLUDED.orders_total_sum,
    orders_bonus_payment_sum = EXCLUDED.orders_bonus_payment_sum,
    orders_bonus_granted_sum = EXCLUDED.orders_bonus_granted_sum,
    order_processing_fee = EXCLUDED.order_processing_fee,
    restaurant_reward_sum = EXCLUDED.restaurant_reward_sum;