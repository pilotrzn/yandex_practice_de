INSERT INTO dds.dm_users
(id, user_id, user_login, user_name)
VALUES (%(id)s, %(user_id)s, %(user_name)s, %(user_login)s)
ON CONFLICT (id) DO UPDATE
SET
    user_id = EXCLUDED.user_id,
    user_name = EXCLUDED.user_name,
    user_login = EXCLUDED.user_login;