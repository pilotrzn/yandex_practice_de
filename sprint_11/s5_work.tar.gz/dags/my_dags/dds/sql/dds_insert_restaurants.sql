INSERT INTO dds.dm_restaurants
(id, restaurant_id, restaurant_name, active_from, active_to)
VALUES (%(id)s, %(restaurant_id)s, %(restaurant_name)s, %(active_from)s, %(active_to)s)
ON CONFLICT (id) DO UPDATE
SET
    restaurant_id = EXCLUDED.restaurant_id,
    restaurant_name = EXCLUDED.restaurant_name,
    active_from = EXCLUDED.active_from,
    active_to = EXCLUDED.active_to;