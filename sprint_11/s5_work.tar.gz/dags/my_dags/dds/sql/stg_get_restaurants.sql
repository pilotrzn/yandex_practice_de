SELECT 
	id, 
	object_id AS restaurant_id, 
	object_value::json->>'name' as restaurant_name,
	update_ts AS active_from,
	CASE 
        WHEN (update_ts)::timestamp <= CURRENT_TIMESTAMP THEN '2099-12-31 00:00:00.000'
        ELSE update_ts
    END AS active_to
FROM stg.ordersystem_restaurants
WHERE id > %(threshold)s 
ORDER BY id ASC
LIMIT %(limit)s;