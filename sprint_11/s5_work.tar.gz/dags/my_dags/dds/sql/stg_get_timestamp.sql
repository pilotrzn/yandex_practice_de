SELECT 
	o.id,
	o.dt ts,
	EXTRACT ( YEAR FROM o.dt) "year",
	EXTRACT ( MONTH	FROM o.dt) "month",
	EXTRACT (DAY FROM o.dt) "day",
	o.dt::date "date",
	o.dt::time "time"
FROM (
SELECT 
	id,
	(object_value::json->>'date')::timestamp dt
FROM stg.ordersystem_orders) o
WHERE id > %(threshold)s 
ORDER BY id ASC
LIMIT %(limit)s;