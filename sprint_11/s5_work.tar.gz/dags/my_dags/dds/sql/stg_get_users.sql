SELECT 
    id, object_id user_id, 
    (object_value::json)->>'name' AS user_name,
    (object_value::json)->>'login' as user_login
FROM stg.ordersystem_users
WHERE id > %(threshold)s 
ORDER BY id ASC
LIMIT %(limit)s;
