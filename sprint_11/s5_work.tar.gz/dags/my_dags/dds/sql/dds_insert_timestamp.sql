INSERT INTO dds.dm_timestamps
(id, ts, "year", "month", "day", "time", "date")
VALUES (%(id)s, %(ts)s, %(year)s, %(month)s, %(day)s, %(time)s, %(date)s)
ON CONFLICT (id) DO UPDATE
SET
    ts = EXCLUDED.ts,
    year = EXCLUDED.year,
    month = EXCLUDED.month,
    day = EXCLUDED.day,
    time = EXCLUDED.time,
    date = EXCLUDED.date;
