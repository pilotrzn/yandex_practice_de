from typing import TypeVar, Generic, List, Type
from psycopg.rows import class_row
from lib import PgConnect


T = TypeVar('T')  # Обобщенный тип


class OriginRepository(Generic[T]):
    def __init__(self, pg: PgConnect, result_class: Type[T]) -> None:
        self._db = pg
        self.return_class = result_class

    def list(self, threshold: int,
             limit: int, query: str) -> List[T]:
        with self._db.client().cursor(row_factory=class_row(self.return_class)) as cur:
            cur.execute(
                query,
                {
                    "threshold": threshold,
                    "limit": limit
                }
            )
            objs = cur.fetchall()
        return objs
