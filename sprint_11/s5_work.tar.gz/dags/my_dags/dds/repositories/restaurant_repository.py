from logging import Logger
from typing import List

from .settings_repository import EtlSetting, StgEtlSettingsRepository
from my_dags.dds.models import RestaurantObject
from .original_repository import OriginRepository
from .query_folder_loader import QueryFolder
from lib import PgConnect
from lib.dict_util import json2str
from psycopg import Connection


class DestRepository:
    def insert(self, conn: Connection, object: RestaurantObject,
               query: str) -> None:
        with conn.cursor() as cur:
            cur.execute(
                query,
                {
                    "id": object.id,
                    "restaurant_id": object.restaurant_id,
                    "restaurant_name": object.restaurant_name,
                    "active_from": object.active_from,
                    "active_to": object.active_to
                },
            )


class RestaurantLoader:
# Преобразуем к строке, чтобы положить в БД.
    WF_KEY = "restaurants_stg_to_dds_workflow"
    LAST_LOADED_ID_KEY = "last_loaded_id"
    BATCH_LIMIT = 2

    def __init__(self, pg_origin: PgConnect,
                 pg_dest: PgConnect, log: Logger) -> None:
        self.pg_dest = pg_dest
        self.origin = OriginRepository[RestaurantObject](pg_origin, RestaurantObject)
        self.stg = DestRepository()
        self.settings_repository = StgEtlSettingsRepository()
        self.log = log
        self.sql_dir = QueryFolder()

    def load(self):
        with self.pg_dest.connection() as conn:
            wf_setting = self.settings_repository.get_setting(conn, self.WF_KEY)
            if not wf_setting:
                wf_setting = EtlSetting(id=0, workflow_key=self.WF_KEY, workflow_settings={self.LAST_LOADED_ID_KEY: -1})

            # Вычитываем очередную пачку объектов.
            query = self.sql_dir.load_sql_file("stg_get_restaurants.sql")

            last_loaded = wf_setting.workflow_settings[self.LAST_LOADED_ID_KEY]
            load_queue = self.origin.list(last_loaded,
                                          self.BATCH_LIMIT, query)
            self.log.info(f"Found {len(load_queue)} restaurants to load.")
            if not load_queue:
                self.log.info("Quitting.")
                return

            # Сохраняем объекты в базу dwh.
            query = self.sql_dir.load_sql_file("dds_insert_restaurants.sql")

            for object in load_queue:
                self.log.info(f"Start loading {object.id}")
                self.stg.insert(conn, object, query)

            wf_setting.workflow_settings[self.LAST_LOADED_ID_KEY] = max([t.id for t in load_queue])
            wf_setting_json = json2str(wf_setting.workflow_settings)
            self.settings_repository.save_setting(conn, wf_setting.workflow_key, wf_setting_json)

            self.log.info(f"Load finished on {wf_setting.workflow_settings[self.LAST_LOADED_ID_KEY]}")
