from typing import Optional

from psycopg import Connection
from psycopg.rows import class_row
from my_dags.dds.models import EtlSetting
from .query_folder_loader import QueryFolder


class StgEtlSettingsRepository:
    def __init__(self):
        self.sql_dir = QueryFolder()

    def get_setting(self, conn:
                    Connection, etl_key: str) -> Optional[EtlSetting]:

        query = self.sql_dir.load_sql_file("dds_get_workflow.sql")
        with conn.cursor(row_factory=class_row(EtlSetting)) as cur:
            cur.execute(
                query,
                {"etl_key": etl_key},
            )
            obj = cur.fetchone()
        return obj

    def save_setting(self, conn: Connection,
                     workflow_key: str, workflow_settings: str) -> None:

        query = self.sql_dir.load_sql_file("save_workflow_setting.sql")
        with conn.cursor() as cur:
            cur.execute(
                query,
                {
                    "etl_key": workflow_key,
                    "etl_setting": workflow_settings
                },
            )
