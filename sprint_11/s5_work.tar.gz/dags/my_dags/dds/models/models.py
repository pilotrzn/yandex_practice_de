from pydantic import BaseModel
from datetime import datetime, date, time
from decimal import Decimal as dec
from typing import Dict


class UserObject(BaseModel):
    id: int
    user_id: str
    user_name: str
    user_login: str


class EtlSetting(BaseModel):
    id: int
    workflow_key: str
    workflow_settings: Dict


class RestaurantObject(BaseModel):
    id: int
    restaurant_id: str
    restaurant_name: str
    active_from: datetime
    active_to: datetime


class TimestampObject(BaseModel):
    id: int
    ts: datetime
    year: int
    month: int
    day: int
    date: date
    time: time


class ProductObject(BaseModel):
    id: int
    product_id: str
    product_name: str
    restaurant_id: int
    product_price: dec
    active_from: datetime
    active_to: datetime
