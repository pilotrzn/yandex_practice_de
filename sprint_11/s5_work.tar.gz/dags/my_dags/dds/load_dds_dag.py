import logging

import pendulum
from airflow.decorators import dag, task
from my_dags.dds.repositories import (
        UserLoader,
        RestaurantLoader,
        TimestampLoader)
from lib import ConnectionBuilder

log = logging.getLogger(__name__)


@dag(
    schedule_interval='0/15 * * * *',
    start_date=pendulum.datetime(2022, 5, 5, tz="UTC"),
    catchup=False,
    tags=['sprint5', 'dds', 'dwh'],
    is_paused_upon_creation=True
)
def dds_load_dag():
    dwh_pg_connect = ConnectionBuilder.pg_conn("PG_WAREHOUSE_CONNECTION")

    @task(task_id="load_users_to_dds")
    def load_users():
        user_loader = UserLoader(dwh_pg_connect, dwh_pg_connect, log)
        user_loader.load()
    # Инициализируем объявленные таски.
    users_load = load_users()

    @task(task_id="load_restaurants_to_dds")
    def load_rests():
        rest_loader = RestaurantLoader(dwh_pg_connect, dwh_pg_connect, log)
        rest_loader.load()
    # Инициализируем объявленные таски.
    rests_load = load_rests()

    @task(task_id="load_timestamps_to_dds")
    def load_ts():
        ts_loader = TimestampLoader(dwh_pg_connect, dwh_pg_connect, log)
        ts_loader.load()
    # Инициализируем объявленные таски.
    ts_load = load_ts()

    users_load, rests_load, ts_load


dds_load_dag = dds_load_dag()
