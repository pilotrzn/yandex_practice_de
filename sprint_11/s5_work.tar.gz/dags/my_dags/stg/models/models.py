from pydantic import BaseModel
from datetime import datetime
from typing import Dict


class RankObj(BaseModel):
    id: int
    name: str
    bonus_percent: float
    min_payment_threshold: float


class UserObj(BaseModel):
    id: int
    order_user_id: str


class EventObj(BaseModel):
    id: int
    event_ts: datetime
    event_type: str
    event_value: str


class EtlSetting(BaseModel):
    id: int
    workflow_key: str
    workflow_settings: Dict
