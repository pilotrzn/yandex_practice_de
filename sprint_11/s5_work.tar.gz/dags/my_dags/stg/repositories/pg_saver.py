from datetime import datetime
from typing import Any

from lib.dict_util import json2str
from psycopg import Connection


class PgSaver:

    def save_object(self, conn: Connection, query: str, id: str,
                    update_ts: datetime, val: Any):

        str_val = json2str(val)
        with conn.cursor() as cur:
            cur.execute(
                query,
                {
                    "id": id,
                    "val": str_val,
                    "update_ts": update_ts
                }
            )