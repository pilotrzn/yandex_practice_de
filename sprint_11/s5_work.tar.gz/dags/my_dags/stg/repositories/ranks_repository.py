from logging import Logger
from typing import List
from pathlib import Path

from .stg_settings_repository import EtlSetting, StgEtlSettingsRepository
from my_dags.stg.models import RankObj
from .query_folder_loader import QueryFolder
from lib import PgConnect
from lib.dict_util import json2str
from psycopg import Connection
from psycopg.rows import class_row


class RanksOriginRepository:
    def __init__(self, pg: PgConnect) -> None:
        self._db = pg

    def list_ranks(self, threshold: int,
                   limit: int, query: str) -> List[RankObj]:

        with self._db.client().cursor(row_factory=class_row(RankObj)) as cur:
            cur.execute(
                query,
                {
                    "threshold": threshold,
                    "limit": limit
                }
            )
            objs = cur.fetchall()
        return objs


class RankDestRepository:
    def insert_rank(self, conn: Connection, rank: RankObj, query: str) -> None:
        with conn.cursor() as cur:
            cur.execute(
                query,
                {
                    "id": rank.id,
                    "name": rank.name,
                    "bonus_percent": rank.bonus_percent,
                    "min_payment_threshold": rank.min_payment_threshold
                },
            )


class RankLoader:
    WF_KEY = "ranks_origin_to_stg_workflow"
    LAST_LOADED_ID_KEY = "last_loaded_id"
    BATCH_LIMIT = 1

    def __init__(self, pg_origin: PgConnect, pg_dest: PgConnect, log: Logger) -> None:
        self.pg_dest = pg_dest
        self.origin = RanksOriginRepository(pg_origin)
        self.stg = RankDestRepository()
        self.settings_repository = StgEtlSettingsRepository()
        self.log = log
        self.sql_dir = QueryFolder()

    def load_ranks(self):
        with self.pg_dest.connection() as conn:
            # Прочитываем состояние загрузки
            # Если настройки еще нет, заводим ее.
            wf_setting = self.settings_repository.get_setting(conn, self.WF_KEY)
            if not wf_setting:
                wf_setting = EtlSetting(id=0, workflow_key=self.WF_KEY, workflow_settings={self.LAST_LOADED_ID_KEY: -1})

            # Вычитываем очередную пачку объектов.
            query = self.sql_dir.load_sql_file("get_public_ranks.sql")
            last_loaded = wf_setting.workflow_settings[self.LAST_LOADED_ID_KEY]
            load_queue = self.origin.list_ranks(last_loaded, 
                                                self.BATCH_LIMIT, query)
            self.log.info(f"Found {len(load_queue)} ranks to load.")
            if not load_queue:
                self.log.info("Quitting.")
                return

            # Сохраняем объекты в базу dwh.
            query = self.sql_dir.load_sql_file("insert_stg_ranks.sql")
            for rank in load_queue:
                self.stg.insert_rank(conn, rank, query)

            wf_setting.workflow_settings[self.LAST_LOADED_ID_KEY] = max([t.id for t in load_queue])
            wf_setting_json = json2str(wf_setting.workflow_settings) 
            self.settings_repository.save_setting(conn, wf_setting.workflow_key, wf_setting_json)

            self.log.info(f"Load finished on {wf_setting.workflow_settings[self.LAST_LOADED_ID_KEY]}")
