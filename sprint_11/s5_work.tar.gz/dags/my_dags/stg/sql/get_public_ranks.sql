SELECT id, name, bonus_percent, min_payment_threshold
FROM ranks
WHERE id > %(threshold)s 
ORDER BY id ASC
LIMIT %(limit)s;