SELECT id, order_user_id
FROM public.users
WHERE id > %(threshold)s 
ORDER BY id ASC
LIMIT %(limit)s;