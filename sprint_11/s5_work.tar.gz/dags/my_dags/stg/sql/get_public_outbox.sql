SELECT id, event_ts, event_type, event_value
FROM public.outbox
WHERE id > %(threshold)s
ORDER BY id ASC
LIMIT %(limit)s;