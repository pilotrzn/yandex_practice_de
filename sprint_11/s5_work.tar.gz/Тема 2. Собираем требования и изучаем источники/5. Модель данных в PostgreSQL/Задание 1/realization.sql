SELECT DISTINCT 
    jsonb_array_elements(event_value::jsonb->'product_payments')->>'product_name' AS product_name
FROM 
    outbox
WHERE 
    event_value::jsonb->'product_payments' IS NOT NULL;